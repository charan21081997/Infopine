function validateProductForm() {
    const productId = document.forms["productForm"]["productId"].value;
    const productName = document.forms["productForm"]["productName"].value;
    const productPrice = document.forms["productForm"]["productPrice"].value;

    if (!/^\d+$/.test(productId)) {
        alert("ProductID must be a number.");
        return false;
    }

    if (productName.trim() === "") {
        alert("ProductName cannot be empty.");
        return false;
    }

    if (!/^\d+(\.\d{1,2})?$/.test(productPrice)) {
        alert("ProductPrice must be a valid number (e.g., 10.99).");
        return false;
    }

    return true;
}

function submitForm(event) {
    event.preventDefault(); // Prevent the default form submission

    const form = document.getElementById("productForm");
    const formData = new FormData(form);
    
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "saveProduct", true);

    xhr.onload = function() {
        if (xhr.status === 200) {
            // Redirect to index.jsp upon successful response
            window.location.href = "addProduct.jsp";
        } else {
            alert("Error saving product: " + xhr.responseText);
        }
    };

    xhr.onerror = function() {
        alert("Request failed.");
    };

    xhr.send(formData); // Send the form data
    return false; // Prevent default form submission
}
