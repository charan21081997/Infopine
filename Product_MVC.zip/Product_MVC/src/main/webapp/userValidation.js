function validateForm() {
	const userId = document.forms["userForm"]["userId"].value;
	const userName = document.forms["userForm"]["userName"].value;
	const userPhoneNo = document.forms["userForm"]["userPhoneNo"].value;
	const productId = document.forms["userForm"]["productId"].value;

	if (!/^\d+$/.test(userId)) {
		alert("UserID must be a number.");
		return false;
	}
	if (userName.trim() === "") {
		alert("UserName cannot be empty.");
		return false;
	}
	if (!/^\d{10}$/.test(userPhoneNo)) {
		alert("UserPhoneNo must be a 10-digit number.");
		return false;
	}
	if (!/^\d+$/.test(productId)) {
		alert("ProductId must be a number.");
		return false;
	}
	return true;
}

function submitForm() {
    if (!validateForm()) {
        return false; // Stop submission if validation fails
    }

    const form = document.getElementById('userForm');
    const formData = new FormData(form);

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "saveUser", true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                // Optionally handle success response
                alert("User saved successfully!");
                window.location.href = "addUser.jsp"; // Redirect to addUser.jsp
            } else {
                // Handle error response
                alert("Error saving user: " + xhr.statusText);
            }
        }
    };

    xhr.send(formData);
    return false; // Prevent default form submission
}