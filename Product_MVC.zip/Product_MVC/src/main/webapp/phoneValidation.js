function validatePhoneForm() {
    const phoneIMEI = document.forms["phoneForm"]["phoneIMEI"].value;
    const phoneBrand = document.forms["phoneForm"]["phoneBrand"].value;
    const phoneSeries = document.forms["phoneForm"]["phoneSeries"].value;
    const phonePrice = document.forms["phoneForm"]["phonePrice"].value;

    if (!/^\d{15}$/.test(phoneIMEI)) {
        alert("PhoneIMEI must be a 15-digit number.");
        return false;
    }

    if (phoneBrand.trim() === "") {
        alert("PhoneBrand cannot be empty.");
        return false;
    }

    if (phoneSeries.trim() === "") {
        alert("PhoneSeries cannot be empty.");
        return false;
    }

    if (!/^\d+(\.\d{1,2})?$/.test(phonePrice)) {
        alert("PhonePrice must be a valid number (e.g., 299.99).");
        return false;
    }

    return true;
}

function submitPhoneForm() {
    if (!validatePhoneForm()) {
        return;
    }

    const formData = new FormData(document.getElementById("phoneForm"));
    const xhr = new XMLHttpRequest();

    xhr.open("POST", "savePhone", true);

    xhr.onload = function() {
        if (xhr.status >= 200 && xhr.status < 300) {
            alert("Phone saved successfully!");
            window.location.href = "addPhone.jsp"; // Redirect to the addPhone page
        } else {
            alert("An error occurred: " + xhr.statusText);
        }
    };

    xhr.onerror = function() {
        alert("An error occurred during the transaction.");
    };

    xhr.send(formData);
}
