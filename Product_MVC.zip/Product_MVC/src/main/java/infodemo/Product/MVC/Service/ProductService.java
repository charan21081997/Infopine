package infodemo.Product.MVC.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import infodemo.Product.MVC.Model.Product;
import infodemo.Product.MVC.Repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository repo;
	
	public void saveDetails(Product p) {
		repo.save(p);
	}
	
	public List<Product> displayProductDetails(){
		return repo.findAll();
	}
	
	public Product findProductDetailsById(int productId) {
		return repo.findById(productId);
	}
	
	public void updateProductDetails(Product p) {
		repo.updateProduct(p);
	}

	public void deleteProductDetails(Product p) {
		repo.deleteProduct(p);
	}
}