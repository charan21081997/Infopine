package infodemo.Product.MVC.Controller;

import java.io.IOException;
import java.lang.ProcessBuilder.Redirect;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import infodemo.Product.MVC.Model.Phone;
import infodemo.Product.MVC.Repository.PhoneRepository;
import infodemo.Product.MVC.Service.PhoneService;

@Controller
public class PhoneController {

	@Autowired
	private PhoneService service;

	@Autowired
	private PhoneController controller;

	@Autowired
	private Phone phone;

	@PostMapping("savePhone")
	public ModelAndView savePhone(@RequestParam("phoneIMEI") int phoneIMEI, @RequestParam("phoneBrand") String phoneBrand,
			@RequestParam("phoneSeries") String phoneSeries, @RequestParam("phonePrice") int phonePrice) {

		phone.setPhoneIMEINO(phoneIMEI);
		phone.setPhoneBrand(phoneBrand);
		phone.setPhoneSeries(phoneSeries);
		phone.setPhonePrice(phonePrice);
		service.savePhoneDetails(phone);

		ModelAndView view=new ModelAndView();
		RedirectView redirect=new RedirectView();
		redirect.setUrl("addPhone.jsp");
		view.setView(redirect);
		return view;
	}
	@GetMapping("displayPhone")
	public ModelAndView displayPhone() {
		List<Phone> pDetails=service.displayPhoneDetails();

		ModelAndView view=new ModelAndView("outputPhone.jsp");
		view.addObject("phoneDetails", pDetails);
		return view;
	}

	@RequestMapping("displayPhoneByIMEI")
	public ModelAndView PhoneById(@RequestParam("phoneIMEI") int phoneIMEI) {
		Phone phoneDetails=service.findPhoneDetailsById(phoneIMEI);

		ModelAndView view=new ModelAndView("phoneDetailsById.jsp");
		view.addObject("phoneDetails", phoneDetails);
		return view;
	}

	@RequestMapping("deletePhone")
	public ModelAndView deletePhoneById(@RequestParam("phoneIMEI") int phoneIMEI) {
		Phone phone=service.findPhoneDetailsById(phoneIMEI);
		service.deletePhoneDetails(phone);
		List<Phone> pDetails=service.displayPhoneDetails();

		ModelAndView view=new ModelAndView("outputPhone.jsp");
		view.addObject("phoneDetails", pDetails);
		return view;
	}

	@RequestMapping("updatePhone")
	public ModelAndView updatePhoneById(@RequestParam("phoneIMEI") int phoneIMEI) {
		Phone phone=service.findPhoneDetailsById(phoneIMEI);

		ModelAndView view=new ModelAndView("updatePhone.jsp");
		view.addObject("phoneDetails",phone);
		return view;
	}

	@RequestMapping("saveUpdatedPhone")
	public ModelAndView saveUpdatedPhone(@RequestParam("phoneIMEI") int phoneIMEI, @RequestParam("phoneBrand") String phoneBrand,
			@RequestParam("phoneSeries") String phoneSeries, @RequestParam("phonePrice") int phonePrice) throws IOException {
	
		phone.setPhoneIMEINO(phoneIMEI);
		phone.setPhoneBrand(phoneBrand);
		phone.setPhoneSeries(phoneSeries);
		phone.setPhonePrice(phonePrice);

		service.updatePhoneDetails(phone);
		List<Phone> phoneDetails=service.displayPhoneDetails();

		ModelAndView view=new ModelAndView("outputPhone.jsp");
		view.addObject("phoneDetails",phoneDetails);
		return view;
	}
}
