package infodemo.Product.MVC.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import infodemo.Product.MVC.Model.Phone;
import infodemo.Product.MVC.Repository.PhoneRepository;

@Service
public class PhoneService {

	@Autowired
	private PhoneRepository repo;
	
	public void savePhoneDetails(Phone p) {
		repo.savePhone(p);
	}
	
	public List<Phone> displayPhoneDetails(){
		return repo.findAll();
	}
	
	public Phone findPhoneDetailsById(int phoneId) {
		return repo.findById(phoneId);
	}
	
	public void updatePhoneDetails(Phone p) {
		repo.updatePhone(p);
	}
	
	public void deletePhoneDetails(Phone p) {
		repo.deletePhone(p);
	}
}
