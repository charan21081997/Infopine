package infodemo.Product.MVC.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import infodemo.Product.MVC.Model.Product;
import infodemo.Product.MVC.Service.ProductService;

@Controller
public class ProductController {

	@Autowired
	public ProductController controller;
	
	@Autowired
	public ProductService service;
	
	@Autowired
	public Product product;
	
	@PostMapping("saveProduct")
	public ModelAndView saveProduct(@RequestParam("productId") int productId, @RequestParam("productName") String productName,
			@RequestParam("productPrice")int productPrice) throws IOException {
	
		product.setProductId(productId);
		product.setProductName(productName);
		product.setProductPrice(productPrice);
		
		service.saveDetails(product);
		
		ModelAndView view=new ModelAndView();
		RedirectView reDirect=new RedirectView();
		reDirect.setUrl("index.jsp");
		view.setView(reDirect);
		return view;
	}
	
	@RequestMapping("/displayProduct")
	public ModelAndView displayProduct() {
		List<Product> pDetails=service.displayProductDetails();
		
		ModelAndView view=new ModelAndView("output.jsp");
		view.addObject("productDetails", pDetails);
		return view;
	}
	
	@RequestMapping("/displayProductById")
	public ModelAndView displayProductById(@RequestParam("productId") int productId) {
		Product productDetails=service.findProductDetailsById(productId);
		
		ModelAndView view=new ModelAndView("productDetailsById.jsp");
		view.addObject("productDetails", productDetails);
		return view;
	}
	
	@RequestMapping("/deleteProduct")
	public ModelAndView deleteProductById(@RequestParam("productId") int productId) {
		Product product=service.findProductDetailsById(productId);
		service.deleteProductDetails(product);
		List<Product>pDetails=service.displayProductDetails();
	
		ModelAndView view=new ModelAndView("output.jsp");
		view.addObject("productDetails",pDetails);
		return view;
	}
	
	@RequestMapping("/updateProduct")
	public ModelAndView updateProductById(@RequestParam("productId") int productId) {
		Product product=service.findProductDetailsById(productId);
		
		ModelAndView view=new ModelAndView("updateProduct.jsp");
		view.addObject("productDetails",product);
		return view;
	}
	
	@RequestMapping("/saveUpdatedProduct")
	public ModelAndView saveUpdatedProduct(@RequestParam("productId") int productId, @RequestParam("productName") String productName,
			@RequestParam("productPrice")int productPrice) throws IOException {
		
		product.setProductId(productId);
		product.setProductName(productName);
		product.setProductPrice(productPrice);
		
		service.updateProductDetails(product);
		List<Product> productDetails=service.displayProductDetails();
		
		ModelAndView view=new ModelAndView("output.jsp");
		view.addObject("productDetails",productDetails);
		return view;
	}
}
