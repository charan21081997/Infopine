package infodemo.Product.MVC.Repository;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.servlet.ModelAndView;

import infodemo.Product.MVC.Model.User;


@Repository
public class UserRepository {

	public static Session getSession() {
		Configuration con=new Configuration().configure().addAnnotatedClass(User.class);
		SessionFactory sf=con.buildSessionFactory();
		Session session=sf.openSession();
		return session;
	}

	public void saveUser(User user) {
		Session session=UserRepository.getSession();
		Transaction trans=session.beginTransaction();

		session.save(user);
		trans.commit();
		session.close();
		System.out.println("User Saved Successfully");
	}

	public List<User> displayUserDetails() {
		Session session=UserRepository.getSession();
		Transaction trans=session.beginTransaction();

		Query<User> query=session.createQuery("from User");
		List<User> uList=query.list();
		trans.commit();
		session.close();
		return uList;
	}

	public User findById(int userId) {
		Session session=UserRepository.getSession();
		Transaction trans=session.beginTransaction();

		User u=session.get(User.class, userId);
		trans.commit();
		session.close();
		return u;
	}

	public void updateUser(User u) {
		Session session=UserRepository.getSession();
		Transaction trans=session.beginTransaction();

		Query<User> query=session.createQuery("UPDATE User set userName= :name, userPhoneNo= :phoneNo, productId= :productId WHERE userId= :userId");
		query.setParameter("name",u.getUserName());
		query.setParameter("phoneNo", u.getUserPhoneNo());
		query.setParameter("productId", u.getProductId());
		query.setParameter("userId", u.getUserId());
		query.executeUpdate();

		trans.commit();
		session.close();
	}

	public void deleteUser(User u) {
		Session session=UserRepository.getSession();
		Transaction trans=session.beginTransaction();

		session.delete(u);
		trans.commit();
		session.close();
	}
}