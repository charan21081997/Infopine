package infodemo.Product.MVC.Controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import infodemo.Product.MVC.Model.User;
import infodemo.Product.MVC.Service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService service;

	@Autowired
	private UserController controller;

	@Autowired
	private User user;

	@PostMapping("saveUser")
	public ModelAndView saveUser(@RequestParam("userId") int userId, @RequestParam("userName") String userName,
			@RequestParam("userPhoneNo") int userPhoneNo, @RequestParam("productId") int productId) {

		user.setUserId(userId);
		user.setUserName(userName);
		user.setUserPhoneNo(userPhoneNo);
		user.setProductId(productId);
		service.saveUser(user);

		ModelAndView view=new ModelAndView();
		RedirectView redirect=new RedirectView();
		redirect.setUrl("addUser.jsp");
		view.setView(redirect);
		return view;
	}

	@GetMapping("displayUser")
	public ModelAndView displayUser() {
		List<User> uDetails=service.displayUserDetails();

		ModelAndView view=new ModelAndView("outputUser.jsp");
		view.addObject("userDetails", uDetails);
		return view;
	}

	@RequestMapping("displayUserByID")
	public ModelAndView userById(@RequestParam("userId") int userId) {
		User userDetails=service.findById(userId);

		ModelAndView view=new ModelAndView("userDetailsById.jsp");
		view.addObject("userDetails", userDetails);
		return view;
	}

	@RequestMapping("deleteUser")
	public ModelAndView deleteUserById(@RequestParam("userId") int userId) {
		User user=service.findById(userId);
		service.deleteUserDetails(user);
		List<User> uDetails=service.displayUserDetails();

		ModelAndView view=new ModelAndView("outputUser.jsp");
		view.addObject("userDetails", uDetails);
		return view;
	}

	@RequestMapping("updateUser")
	public ModelAndView updateUserById(@RequestParam("userId") int userId) {
		User user=service.findById(userId);

		ModelAndView view=new ModelAndView("updateUser.jsp");
		view.addObject("userDetails",user);
		return view;
	}
	
	@RequestMapping("saveUpdatedUser")
	public ModelAndView saveUpdatedUser(@RequestParam("userId") int userId, @RequestParam("userName") String userName,
			@RequestParam("userPhoneNo") int userPhoneNo, @RequestParam("productId") int productId) throws IOException  {

		user.setUserId(userId);
		user.setUserName(userName);
		user.setUserPhoneNo(userPhoneNo);
		user.setProductId(productId);

		service.updateUserDetails(user);
		List<User> userDetails=service.displayUserDetails();

		ModelAndView view=new ModelAndView("outputUser.jsp");
		view.addObject("userDetails",userDetails);
		return view;
	}
}
