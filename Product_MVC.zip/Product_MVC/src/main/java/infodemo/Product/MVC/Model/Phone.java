package infodemo.Product.MVC.Model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity
@Component
public class Phone {

	@Id
	private int phoneIMEINO;
	private String phoneBrand;
	private String phoneSeries;
	private int phonePrice;

	public int getPhoneIMEINO() {
		return phoneIMEINO;
	}
	public void setPhoneIMEINO(int phoneIMEINO) {
		this.phoneIMEINO = phoneIMEINO;
	}
	public String getPhoneBrand() {
		return phoneBrand;
	}
	public void setPhoneBrand(String phoneBrand) {
		this.phoneBrand = phoneBrand;
	}
	public String getPhoneSeries() {
		return phoneSeries;
	}
	public void setPhoneSeries(String phoneSeries) {
		this.phoneSeries = phoneSeries;
	}
	public int getPhonePrice() {
		return phonePrice;
	}
	public void setPhonePrice(int phonePrice) {
		this.phonePrice = phonePrice;
	}
}
