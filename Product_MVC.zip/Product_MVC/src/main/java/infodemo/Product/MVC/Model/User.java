package infodemo.Product.MVC.Model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity
@Component
public class User {

	@Id
	private int userId;
	private String userName;
	private int userPhoneNo;
	private int productId;

	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getUserPhoneNo() {
		return userPhoneNo;
	}
	public void setUserPhoneNo(int userPhoneNo) {
		this.userPhoneNo = userPhoneNo;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
}
