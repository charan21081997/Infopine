
package infodemo.Product.MVC.Repository;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;

import infodemo.Product.MVC.Model.Product;

@Repository
public class ProductRepository {
	
	public static Session getSession() {
		Configuration con=new Configuration().configure().addAnnotatedClass(Product.class);
		SessionFactory sf=con.buildSessionFactory();
		Session session=sf.openSession();
		return session;
	}
	
	public void save(Product product) {
		Session session=ProductRepository.getSession();
		Transaction trans=session.beginTransaction();
		
		session.save(product);
		trans.commit();
		session.close();
		System.out.println("Product Saved Successfully");
	}
	
	public List<Product> findAll(){
		Session session=ProductRepository.getSession();
		Transaction trans=session.beginTransaction();
		
		Query<Product> query=session.createQuery("from Product");
		List<Product> lProduct=query.list();
		trans.commit();
		session.close();
		return lProduct;
	}

	public Product findById(int id) {
		Session session=ProductRepository.getSession();
		Transaction trans=session.beginTransaction();
		
		Product p=session.get(Product.class, id);
		trans.commit();
		session.close();
		return p;
	}
	
	public void updateProduct(Product p) {
		Session session=ProductRepository.getSession();
		Transaction trans=session.beginTransaction();
		
		Query<Product> query=session.createQuery("UPDATE Product SET productName= :name, productPrice= :price WHERE productId= :id");
		query.setParameter("name", p.getProductName());
		query.setParameter("price", p.getProductPrice());
		query.setParameter("id", p.getProductId());
		query.executeUpdate();
		
		trans.commit();
		session.close();
	}
	public void deleteProduct(Product p) {
		Session session=ProductRepository.getSession();
		Transaction trans=session.beginTransaction();
		
		session.delete(p);
		trans.commit();
		session.close();
	}
}
