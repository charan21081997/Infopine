package infodemo.Product.MVC.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import infodemo.Product.MVC.Model.User;
import infodemo.Product.MVC.Repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository repo;

	public void saveUser(User user) {
		repo.saveUser(user);
	}

	public List<User> displayUserDetails() {
		return repo.displayUserDetails();
	}

	public User findById(int userId) {
		return repo.findById(userId);
	}

	public void deleteUserDetails(User user) {
		repo.deleteUser(user);
	}

	public void updateUserDetails(User user) {
		repo.updateUser(user);
	}
}
