package infodemo.Product.MVC;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "infodemo.Product.MVC")
public class ProductConfig {

}
