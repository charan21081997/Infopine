package infodemo.Product.MVC.Repository;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import infodemo.Product.MVC.Model.Phone;

@Repository
public class PhoneRepository {

	public static Session getSession() {
		Configuration con=new Configuration().configure().addAnnotatedClass(Phone.class);
		SessionFactory sf=con.buildSessionFactory();
		Session session=sf.openSession();
		return session;
	}
	
	public void savePhone(Phone phone) {
		Session session=PhoneRepository.getSession();
		Transaction trans=session.beginTransaction();
		
		session.save(phone);
		trans.commit();
		session.close();
		System.out.println("Phone Saved Successfully");
	}
	
	public List<Phone>findAll(){
		Session session=PhoneRepository.getSession();
		Transaction trans=session.beginTransaction();
		
		Query<Phone> query=session.createQuery("from Phone");
		List<Phone> lPhone=query.list();
		trans.commit();
		session.close();
		return lPhone;
	}
	
	public Phone findById(int imei) {
		Session session=PhoneRepository.getSession();
		Transaction trans=session.beginTransaction();
		
		Phone p=session.get(Phone.class, imei);
		trans.commit();
		session.close();
		return p;
	}
	
	public void updatePhone(Phone p) {
		Session session=PhoneRepository.getSession();
		Transaction trans=session.beginTransaction();
		
		Query<Phone>query=session.createQuery("UPDATE Phone SET phoneBrand= :brand, phoneSeries= :series, phonePrice= :price WHERE phoneIMEINO= :imei");
		query.setParameter("brand", p.getPhoneBrand());
		query.setParameter("series", p.getPhoneSeries());
		query.setParameter("price", p.getPhonePrice());
		query.setParameter("imei", p.getPhoneIMEINO());
		query.executeUpdate();

		trans.commit();
		session.close();
	}
	
	public void deletePhone(Phone p) {
		Session session=PhoneRepository.getSession();
		Transaction trans=session.beginTransaction();
		
		session.delete(p);
		trans.commit();
		session.close();
	}
}
