package com.Infopine.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.Infopine.Model.User;
import com.Infopine.Service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService service;

	@Autowired
	private User user;

	@GetMapping("/")
	public String index() {
		return "index";
	}

	@GetMapping("/success")
	public ModelAndView showSuccessPage() {
	    ModelAndView modelAndView = new ModelAndView("success"); // View name for success.jsp
	    modelAndView.addObject("message", "User saved successfully!"); // Add any model attributes needed
	    return modelAndView;
	}

	@PostMapping("saveUser")
	public ModelAndView saveUser( @RequestParam("userName") String userName,
			@RequestParam("userPhoneNo") String userPhoneNo, @RequestParam("productId") int productId) {

		user.setUserName(userName);
		user.setUserPhoneNo(userPhoneNo);
		user.setProductId(productId);
		service.saveUser(user);

		ModelAndView view=new ModelAndView();
		RedirectView redirect=new RedirectView();
		redirect.setUrl("success");
		view.setView(redirect);
		return view;
	}
}
