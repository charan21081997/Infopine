/*document.getElementById('userForm').addEventListener('submit', function(event) {
	event.preventDefault(); 
	
	const userName = document.getElementById('userName').value.trim();
	const userPhoneNo = document.getElementById('userPhoneNo').value.trim();
	const productId = document.getElementById('productId').value.trim();

	let isValid = true;
	let errorMessages = [];

	if (userName === "" && userPhoneNo === "" && productId === "") {
		isValid = false;
		errorMessages.push('All fields must be filled out.');
	} else {
		if (userName === "") {
			isValid = false;
			errorMessages.push('User Name must be filled out.');
		}
		if (userPhoneNo === "") {
			isValid = false;
			errorMessages.push('Phone number must be filled out.');
		}
		if (productId === "") {
			isValid = false;
			errorMessages.push('Product ID must be filled out.');
		}

		const numberRegex = /^\d+$/;
		if (userPhoneNo && (!numberRegex.test(userPhoneNo) || userPhoneNo.length !== 10)) {
			isValid = false;
			errorMessages.push('Phone number must be a 10-digit number.');
		}
		if (productId && !numberRegex.test(productId)) {
			isValid = false;
			errorMessages.push('Product ID must be a number.');
		}

		const nameRegex = /^[A-Za-z\s]+$/;
		if (userName && !nameRegex.test(userName)) {
			isValid = false;
			errorMessages.push('User Name must not contain numbers or special characters.');
		}
	}*/

/*if (!isValid) {
	alert(errorMessages.join('\n'));
	return; // Exit the function if not valid
}

const xhr = new XMLHttpRequest();
xhr.open('POST', 'saveUser', true);
xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

xhr.onreadystatechange = function() {
	if (xhr.readyState === XMLHttpRequest.DONE) {
		if (xhr.status === 200) {
			// Redirect to success.jsp after saving the data
			window.location.href = "success";
		} else {
			alert('Error: ' + xhr.status + ' ' + xhr.statusText);
		}
	}
};

const data = new URLSearchParams();
data.append('userName', userName);
data.append('userPhoneNo', userPhoneNo);
data.append('productId', productId);

xhr.send(data.toString());
});*/

$('#userForm').on('submit', function(event) {
	event.preventDefault();

	const userName = $('#userName').val().trim();
	const userPhoneNo = $('#userPhoneNo').val().trim();
	const productId = $('#productId').val().trim();

	let isValid = true;
	let errorMessages = [];

	if (userName === "" && userPhoneNo === "" && productId === "") {
		isValid = false;
		errorMessages.push('All fields must be filled out.');
	} else {
		if (userName === "") {
			isValid = false;
			errorMessages.push('User Name must be filled out.');
		}
		if (userPhoneNo === "") {
			isValid = false;
			errorMessages.push('Phone number must be filled out.');
		}
		if (productId === "") {
			isValid = false;
			errorMessages.push('Product ID must be filled out.');
		}

		const numberRegex = /^\d+$/;
		if (userPhoneNo && (!numberRegex.test(userPhoneNo) || userPhoneNo.length !== 10)) {
			isValid = false;
			errorMessages.push('Phone number must be a 10-digit number.');
		}
		if (productId && !numberRegex.test(productId)) {
			isValid = false;
			errorMessages.push('Product ID must be a number.');
		}

		const nameRegex = /^[A-Za-z\s]+$/;
		if (userName && !nameRegex.test(userName)) {
			isValid = false;
			errorMessages.push('User Name must not contain numbers or special characters.');
		}
	}
	if (!isValid) {
		alert(errorMessages.join('\n'));
		return;
	}

	$.ajax({
		url: 'saveUser',
		type: 'POST',
		data: {
			userName: userName,
			userPhoneNo: userPhoneNo,
			productId: productId
		},
		success: function(response) {
			window.location.href = "success";
		},
		error: function(xhr) {
			alert('Error: ' + xhr.status + ' ' + xhr.statusText);
		}
	});
});
